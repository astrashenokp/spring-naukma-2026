package com.ukma.cctv.security;

import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.concurrent.Callable;

public final class SecurityScopeRunner {

    public static final ScopedValue<SecurityContext> SECURITY_CONTEXT =
            ScopedValue.newInstance();

    private SecurityScopeRunner() {}

    public static <T> T callWithContext(SecurityContext context, Callable<T> task) throws Exception {
        return ScopedValue.where(SECURITY_CONTEXT, context)
                .call(task::call);
    }

    public static SecurityContext currentContext() {
        return SECURITY_CONTEXT.isBound()
                ? SECURITY_CONTEXT.get()
                : SecurityContextHolder.getContext();
    }
}
