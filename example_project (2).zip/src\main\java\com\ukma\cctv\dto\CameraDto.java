package com.ukma.cctv.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public record CameraDto(
    @NotBlank(message = "Location cannot be blank")
    String location,
    
    @Pattern(regexp = "^([0-9]{1,3}\\.){3}[0-9]{1,3}$", message = "Invalid IP address")
    String ipAddress
) {}
