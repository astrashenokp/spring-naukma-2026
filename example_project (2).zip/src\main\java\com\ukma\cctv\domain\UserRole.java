package com.ukma.cctv.domain;

public enum UserRole {
    ROLE_VIEWER,
    ROLE_OPERATOR,
    ROLE_ADMIN
}
