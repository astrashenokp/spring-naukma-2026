package com.ukma.cctv;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ukma.cctv.controller.CameraController;
import com.ukma.cctv.security.config.SecurityConfiguration;
import com.ukma.cctv.security.error.ProblemDetailAccessDeniedHandler;
import com.ukma.cctv.security.error.ProblemDetailAuthenticationEntryPoint;
import com.ukma.cctv.security.jwt.JwtAuthenticationFilter;
import com.ukma.cctv.security.jwt.JwtValidatorService;
import com.ukma.cctv.service.CameraManagementService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.webmvc.test.autoconfigure.MockMvcBuilderCustomizer;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(CameraController.class)
@Import({
        SecurityConfiguration.class,
        JwtAuthenticationFilter.class,
        ProblemDetailAuthenticationEntryPoint.class,
        ProblemDetailAccessDeniedHandler.class,
        ObjectMapper.class,
        CameraControllerSecurityTest.SecurityTestConfig.class
})
class CameraControllerSecurityTest {

    @TestConfiguration
    static class SecurityTestConfig {
        @Bean
        public MockMvcBuilderCustomizer securityMockMvcBuilderCustomizer() {
            return builder -> builder.apply(SecurityMockMvcConfigurers.springSecurity());
        }
    }

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private CameraManagementService cameraService;

    @MockitoBean
    private JwtValidatorService jwtValidatorService;

    @MockitoBean
    private com.ukma.cctv.security.jwt.JwtService jwtService;

    @MockitoBean
    private UserDetailsService userDetailsService;

    @Test
    void getCameras_WhenUnauthenticated_ShouldReturnUnauthorized() throws Exception {
        mockMvc.perform(get("/api/v1/cameras"))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @WithMockUser(username = "operator", roles = {"OPERATOR"})
    void deleteCamera_WhenForbiddenRole_ShouldReturnForbidden() throws Exception {
        mockMvc.perform(delete("/api/v1/cameras/42"))
                .andExpect(status().isForbidden());
    }

    @Test
    @WithMockUser(username = "admin", roles = {"ADMIN"})
    void deleteCamera_WhenAdminRole_ShouldReturnNoContent() throws Exception {
        mockMvc.perform(delete("/api/v1/cameras/42"))
                .andExpect(status().isNoContent());
    }
}
