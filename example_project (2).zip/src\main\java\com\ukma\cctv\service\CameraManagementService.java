package com.ukma.cctv.service;

import com.ukma.cctv.domain.Camera;
import com.ukma.cctv.dto.CameraDto;
import com.ukma.cctv.dto.CameraResponse;
import com.ukma.cctv.dto.UpdateStreamCommand;
import com.ukma.cctv.repository.CameraRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CameraManagementService {

    private final CameraRepository cameraRepository;

    public CameraManagementService(CameraRepository cameraRepository) {
        this.cameraRepository = cameraRepository;
    }

    @PreAuthorize("hasAnyRole('VIEWER', 'OPERATOR', 'ADMIN')")
    public List<CameraResponse> getAllCameras() {
        return cameraRepository.findAll().stream()
                .map(CameraResponse::fromEntity)
                .toList();
    }

    @PreAuthorize("hasAnyRole('VIEWER', 'OPERATOR', 'ADMIN')")
    public CameraResponse getCameraById(Long cameraId) {
        return cameraRepository.findById(cameraId)
                .map(CameraResponse::fromEntity)
                .orElseThrow(() -> new IllegalArgumentException("Камеру з ID " + cameraId + " не знайдено."));
    }

    @PreAuthorize("hasRole('ADMIN')")
    public CameraResponse createCamera(CameraDto cameraDto) {
        Camera camera = new Camera(cameraDto.location(), cameraDto.ipAddress());
        Camera saved = cameraRepository.save(camera);
        return CameraResponse.fromEntity(saved);
    }

    @PreAuthorize("hasRole('ADMIN')")
    public void deleteCamera(Long cameraId) {
        cameraRepository.deleteById(cameraId);
    }

    @PreAuthorize("hasRole('OPERATOR') and #command.bitrate() <= 5000")
    public void updateStreamQuality(Long cameraId, UpdateStreamCommand command) {
        // Оновлення параметрів відеопотоку оператором у межах ліміту бітрейту
    }
}
