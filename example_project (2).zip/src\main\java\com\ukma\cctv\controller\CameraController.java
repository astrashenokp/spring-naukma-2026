package com.ukma.cctv.controller;

import com.ukma.cctv.dto.CameraDto;
import com.ukma.cctv.dto.CameraResponse;
import com.ukma.cctv.dto.UpdateStreamCommand;
import com.ukma.cctv.service.CameraManagementService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/cameras")
public class CameraController {

    private final CameraManagementService cameraService;

    public CameraController(CameraManagementService cameraService) {
        this.cameraService = cameraService;
    }

    @GetMapping
    public ResponseEntity<List<CameraResponse>> getCameras() {
        return ResponseEntity.ok(cameraService.getAllCameras());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CameraResponse> getCameraById(@PathVariable Long id) {
        return ResponseEntity.ok(cameraService.getCameraById(id));
    }

    @PostMapping
    public ResponseEntity<CameraResponse> createCamera(@Valid @RequestBody CameraDto cameraDto) {
        CameraResponse created = cameraService.createCamera(cameraDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public ResponseEntity<Void> deleteCamera(@PathVariable Long id) {
        cameraService.deleteCamera(id);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{id}/stream-quality")
    public ResponseEntity<Void> updateStreamQuality(
            @PathVariable Long id,
            @Valid @RequestBody UpdateStreamCommand command) {
        cameraService.updateStreamQuality(id, command);
        return ResponseEntity.ok().build();
    }
}
