package com.ukma.cctv.config;

import com.ukma.cctv.domain.Camera;
import com.ukma.cctv.domain.UserEntity;
import com.ukma.cctv.domain.UserRole;
import com.ukma.cctv.repository.CameraRepository;
import com.ukma.cctv.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Bean
    public CommandLineRunner initData(
            UserRepository userRepository,
            CameraRepository cameraRepository,
            PasswordEncoder passwordEncoder) {
        return args -> {
            if (userRepository.count() == 0) {
                userRepository.save(new UserEntity(
                        "admin",
                        passwordEncoder.encode("admin123"),
                        UserRole.ROLE_ADMIN
                ));
                userRepository.save(new UserEntity(
                        "operator",
                        passwordEncoder.encode("operator123"),
                        UserRole.ROLE_OPERATOR
                ));
                userRepository.save(new UserEntity(
                        "viewer",
                        passwordEncoder.encode("viewer123"),
                        UserRole.ROLE_VIEWER
                ));
            }

            if (cameraRepository.count() == 0) {
                cameraRepository.save(new Camera("Головний вхід", "192.168.1.101"));
                cameraRepository.save(new Camera("Паркінг", "192.168.1.102"));
                cameraRepository.save(new Camera("Серверна кімната", "192.168.1.103"));
            }
        };
    }
}
