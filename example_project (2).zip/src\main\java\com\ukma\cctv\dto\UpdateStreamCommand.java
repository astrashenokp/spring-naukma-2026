package com.ukma.cctv.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;

public record UpdateStreamCommand(
        @Min(100) @Max(10000)
        int bitrate
) {}
