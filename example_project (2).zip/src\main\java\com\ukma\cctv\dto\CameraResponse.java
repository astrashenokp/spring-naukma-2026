package com.ukma.cctv.dto;

import com.ukma.cctv.domain.Camera;

public record CameraResponse(
        Long id,
        String location,
        String ipAddress,
        boolean active
) {
    public static CameraResponse fromEntity(Camera camera) {
        return new CameraResponse(
                camera.getId(),
                camera.getLocation(),
                camera.getIpAddress(),
                camera.isActive()
        );
    }
}
