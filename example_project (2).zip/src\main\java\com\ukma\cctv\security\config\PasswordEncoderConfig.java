package com.ukma.cctv.security.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.argon2.Argon2PasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration(proxyBeanMethods = false)
public class PasswordEncoderConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new Argon2PasswordEncoder(
                16,    // Довжина солі в байтах
                32,    // Довжина вихідного хешу в байтах
                1,     // Кількість паралельних потоків обчислення
                16384, // Обсяг оперативної пам'яті в кілобайтах (16 МБ)
                3      // Кількість ітерацій обчислення
        );
    }
}
